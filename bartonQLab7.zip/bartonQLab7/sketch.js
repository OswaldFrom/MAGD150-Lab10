let rotatingLine = 0;    
let speed = 0.05;   
let hitMarker=0; 


let hits = 0;
let misses = 0;
let scoreTracker=[];

let lastClick=0;

function setup() {
  createCanvas(500, 500);
  hitZone = random(PI / 4, PI / 2); 
}

function draw() {
  background(0);

  translate(width / 2, height / 2); 

  scale(1.2);
  
  stroke(255);
  noFill();
  ellipse(0, 0, 200, 200);

  stroke(255, 0, 0);
  push();
  rotate(hitMarker);
  line(0, 0, 100, 0);
  pop();


  stroke(0, 255, 0);
  push();
  rotate(rotatingLine);
  line(0, 0, 100, 0);
  pop();
  //now that I learned to rotate I feel unstoppable

  rotatingLine += speed;
  if (rotatingLine > PI*2) rotatingLine -= PI*2;
  
  noFill();
  noStroke();
  fill(255);
  text("Perfect " + hits + "  You Suck " + misses, -55, -125);
  text("click when the lines meet", -65,-150);
  
    stroke(150);
  for (let i = 0; i < PI*2; i += PI / 6) {
    push();
    rotate(i);
    line(90, 0, 100, 0);
    pop();
  }  
}




function mouseReleased() {
    if (abs(rotatingLine - hitMarker) < 0.1) {
      speed += 0.05;
      console.log('nice');
      lastClick=1;
      scoreTracker.push(1);
      }else {console.log('could be better');
             lastClick=0;
       scoreTracker.push(0);
        
      }
  
  scoreTracker=[lastClick];
  
         hitMarker = random(PI / 4, PI / 2);
  
  for (let i = 0; i < scoreTracker.length; i++) {
    if (scoreTracker[i] == [1]) {
      hits++;
    } else {
      misses++;
    }
  }
//AHHH I did the whole thing without angleMode and now it'd ruin it
  //also hit detection is not accurate lol

 }   


