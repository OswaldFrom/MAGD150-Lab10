let ship;
let bullets = [];
let color1=125,color2=125,color3=125;

let enemies = [];
let enemySpawnTimer = 0;

let loser = false;

let score = 0;

function setup() {
  
  new Canvas(1000, 600);
  
  //player create
  
  ship = new Sprite();
  ship.width = 40;
  ship.height = 20;
  ship.color = color(color1,color2,color3);
  ship.x = 100;
  ship.y = height/2;
  ship.collider = 'k';
  //k detects collision

  ship.draw = function () {
    fill(ship.color);
    noStroke();
    let w = ship.width;
    let h = ship.height;
    triangle(-w/2, -h/2, -w/2, h/2, w/2, 0);
  }
}

function draw() {
  
   //score stuff, I could not figure out how to handle the score based on collision, when trying to add      based on bullets colliding it removed all collision and breaks
  
   //based on time now
  
   if (frameCount % 30 === 0) {
   score += 1;
   //adds score when fps is divisable by 30 for each second, not fully correct but 60fps made it seem off    so I cut it in half 
}
  
  //you lose stuff
    
   if (loser){
    fill(255);
    textSize(20);
    textAlign(CENTER,CENTER);
    
    text("Time Survived: " + int(score) +" seconds", width/2, height/2 + 30);
    
    text("game over",width/2, height/2);
    frameRate(0);
    return;
  }
  
  background(20);
  
  //player movement and color
  if (keyIsDown(RIGHT_ARROW)) ship.x += 4;
  if (keyIsDown(LEFT_ARROW))  ship.x -= 4;
  if (keyIsDown(UP_ARROW))    ship.y -= 6;
  if (keyIsDown(DOWN_ARROW))  ship.y += 6;

  if (keyIsDown(RIGHT_ARROW)) color1 += int(random(-10,10));
  if (keyIsDown(LEFT_ARROW))  color2 += int(random(-10,10));
  if (keyIsDown(UP_ARROW))    color3 += int(random(-10,10));
  if (keyIsDown(DOWN_ARROW))  {
    color1 += int(random(-10,10));
    color2 += int(random(-10,10));
    color3 += int(random(-10,10));
  }
    color1=constrain(color1, 0, 255);
    color2=constrain(color2, 0, 255);
    color3=constrain(color3, 0, 255);
  
    ship.color=color(color1,color2,color3);
    //keeps the color proper and in bounds
  
  ship.x = constrain(ship.x, ship.width/2, width-ship.width/2);
  ship.y = constrain(ship.y, ship.height/2, height-ship.height/2);
  
  for (let i = bullets.length-1; i>=0; i--) {
    if (bullets[i].x>width) {
      bullets[i].remove();
      bullets.splice(i, 1);
      //keeps it from stuttering lol, reverse for removes items from array without potential skipping uhh         at least I think it prevents skips
    }
  }

     //enemy data start
  
    if (frameCount % 30 === 0) {
      //spawns enemy with frame divisability
    spawnEnemy();
  }

  for (let i = enemies.length - 1; i >= 0; i--) {
    let e = enemies[i];
    if (!(e instanceof Sprite)) continue;
    //lost in the sauce of undefined variables, makes sure that it's valid

    e.x -= 5;
    //this changes the speed of right to left movement
    
    if (e.vars && e.vars.baseY !== undefined && e.vars.offset !== undefined) {
    e.y = e.vars.baseY + sin((frameCount*1) + e.vars.offset) * 100;
      //this line modifies the movement of the enemies
      // and keeps undefined variables out
  }  
    
    if (ship.overlaps(e)) {
      loser = true;
        // Hides all sprites when collision occurs
      ship.visible = false;
      for (let bullet of bullets) {
        bullet.visible = false;
      }
      for (let enemy of enemies) {
        enemy.visible = false;
      }
        //checks the objects of the arrays and makes the screen black
  
    }
    
      if (e.x < -e.width) {
        e.remove();
        enemies.splice(i, 1);
        //removes enemy after they move too far left, outs them from beggining of the array
      
    }
  }  
}

function keyPressed() {
  if (key === ' ') {
    let bullet = new Sprite();
    bullet.width = 10;
    bullet.height = 4;
    bullet.color = color(random(255), random(255), random(255));
    bullet.x = ship.x+ship.width/2;
    bullet.y = ship.y;
    bullet.vel.x = 8;
    bullet.collider = 'k';// I cant believe how funky this is
    bullets.push(bullet);
  }
}

function spawnEnemy() {
  let enemy = new Sprite();
  enemy.width = 40;
  enemy.height = 20;
  enemy.x = width+20;

  //vars stores custom variables without obliterating p5
  //more undefined nonsense
  if (!enemy.vars) enemy.vars = {};
  enemy.vars.baseY = random(0+enemy.height*3, height-enemy.height*3);
  enemy.vars.offset = random(TWO_PI); 
  enemy.y = enemy.vars.baseY;
  enemy.color = 'red';
  enemies.push(enemy);
}