var static=1;

function setup() {
  createCanvas(500, 500);  
}

function draw() {

  background(250, 180,80);
  fill('grey');
  square(150, 150, 200, 20);
  
  noFill();
fill('white');
  if (static==1) fill('blue');
  if (static==2) fill('black');
  if (static==3)  {
    
  noFill();
text('PLAY',190,195);
  } 
  square(170,170,160,20); 
  noFill();
  fill(101,67,33);
  square(0,350, 500);   
  noFill(); 
  square(300, 335, 10,2);
  noFill();
  stroke(0);
  noFill();   
}

  function mousePressed(){

   if (static==1){
     if (dist(mouseX,mouseY,305,340)<5) static=2;
   }             
    else if (static==2){ if (dist(mouseX,mouseY,305,340)<5) static=1;
    } 
    else if (static==3){ if (dist(mouseX,mouseY,305,340)<5) static=1;
  }
  }
  function keyPressed(){
    if (static==1){
      
      if (keyCode===ENTER ){
        static=3;
        
      }
    }
  }

