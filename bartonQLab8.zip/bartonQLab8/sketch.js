let characterImg;
let darkSunImg;

let storedPositionX;
let storedPositionY;
let xCord;
let yCord;

let characterWords=false;

let delay=0;

function preload(){
  characterImg = loadImage('https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/d0334900-009f-42a2-9044-830d25d369ff/d9zsklo-1ed99077-bd39-4829-921b-2af6229b41bd.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7InBhdGgiOiJcL2ZcL2QwMzM0OTAwLTAwOWYtNDJhMi05MDQ0LTgzMGQyNWQzNjlmZlwvZDl6c2tsby0xZWQ5OTA3Ny1iZDM5LTQ4MjktOTIxYi0yYWY2MjI5YjQxYmQucG5nIn1dXSwiYXVkIjpbInVybjpzZXJ2aWNlOmZpbGUuZG93bmxvYWQiXX0.-olu3B4WNwN6iQbtLwq-3pd6EjjNqAO5iMlo9xAra6Q'); 
  
  darkSunImg = loadImage('https://i.imgur.com/841SOQU.gif');
  }

function mouseClicked(){ 
    storedPositionX=pmouseX;
    storedPositionY=max(pmouseY,180);
   
  let d = dist(mouseX, mouseY, 177, 100);
  if (d < 82.5) {
    characterWords = true;
    speechTimer = millis();
  }  
}

function setup() {
  createCanvas(500, 500);
  storedPositionX=0;
  storedPositionY=450;
  
  xCord = storedPositionX;
  yCord = storedPositionY;
}

function draw() {
  background(255);
  textFont("Monospace");
  
  
 fill("darkgreen") 
  square(0,200,500)
 fill("gray")
  rect(0,0,500,200)
 fill(10)
  circle(178,100,169)
  image(darkSunImg, 50,-50)
  image(characterImg, xCord,yCord, 50, 50) 
 
xCord = lerp(xCord, storedPositionX, 0.05);
yCord = lerp(yCord, storedPositionY, 0.05);  
  
 if (characterWords) {
    fill(255);
    stroke(0);
    rect(xCord, yCord - 40, 170, 30, 50); 
   
    fill(0);
    textSize(13);
    textAlign(CENTER, CENTER);
    text("That doesn't look good!", xCord + 85, yCord - 25);

    if (millis() - speechTimer > 2500) {
      characterWords = false;
    }
  } 
}