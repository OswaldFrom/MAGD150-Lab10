let player;
let movingCube;

function setup() {
  createCanvas(500, 500);

  player = createSprite(250, 250, 20, 20);
  
  movingCube = createSprite(200, 200, 20, 20);
  movingCube.velocity.x = 5;
  movingCube.velocity.y = 5;
}

function draw() {
  background(0);

  player.position.x = mouseX;
  player.position.y = mouseY;

  if (movingCube.position.x<=movingCube.width/2 || movingCube.position.x>=width-movingCube.width/2) {
    movingCube.velocity.x *= -1;
  }
  if (movingCube.position.y <= movingCube.height/2 || movingCube.position.y >= height - movingCube.height/2) {
    movingCube.velocity.y *= -1;
  }
  if (movingCube.overlap(player)) {

    //I absolutly hate absolutes, and it makes it bug out a bit, so idk what I should have used. There's probably a much better way to handle collision.
    if (abs(movingCube.position.x - player.position.x) > abs(movingCube.position.y - player.position.y)) {
      movingCube.velocity.x *= -1;
    } else {
      movingCube.velocity.y *= -1;
    }
  }
 drawSprites();
}