function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(75);
  
  let xyaxismiddle=250;
  let q1center=125;
  let q4center=375;
  
  colorMode(RGB, 255);
  
    line(250,0,250,500);
    line(0,250,500,250);
  noFill();
  circle(250,250, 375);
  
      if(mouseX<xyaxismiddle  & mouseY > xyaxismiddle){
  fill(255,40,240);
  rect(pmouseX-15, pmouseY-15, 30, 30);
  noFill();
  }
      if(mouseX > xyaxismiddle  & mouseY < xyaxismiddle){
    fill(0,40,240);
    triangle(pmouseX-10, pmouseY+17, pmouseX+4, pmouseY-15, pmouseX+18, pmouseY+17);
    }
  
      if(mouseY < xyaxismiddle  & mouseX < xyaxismiddle){
        //red circle
   fill(255,0,0)
        //tried to get it center on the circle line
   circle(sqrt(pmouseX)*-1+q1center-8,sqrt(pmouseY)*-1+q1center-8,-25);
   noFill(); 
    }
  
      if(mouseX > xyaxismiddle & mouseY > xyaxismiddle){
        //green circle
        fill(0,255,40)
        circle(radians(pmouseX*2)+q4center,radians(pmouseY*2)+q4center,-25);
        noFill();  
  }
  
  
   //click to add lag by changing the fps which is funny
      if (mouseIsPressed === true) {
    frameRate(10);
  }   else {
    frameRate(144);
  }
  
  
  
}