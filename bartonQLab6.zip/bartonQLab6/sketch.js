let num=0;
let xCord=[];

function setup() {
  createCanvas(500, 500); 
  background(0);
  fill('white');
  
  for (let x = 20; x < 100; x += 20) {
    xCord.push(x);
  } 
}

function draw() {

  if (mouseIsPressed){
text (num,50,50);
    
  }
}

function mousePressed(){
  let mouse=[pmouseX, pmouseY];
  print(mouse);
  num++
  fill('white');
  background(0);
  circle(mouse[0], mouse[1],10);
  
  
  for (let i=0;i<xCord.length; i++){
    xCord[i] -= random(-1,1);
  circle(mouse[0]+xCord[0],mouse[1]+xCord[0],10); 
  
  } 
  
  
  
  
}
