//balloons powerline scene //im not creative
function setup() {
  createCanvas(500, 300); 
}
function draw() {
  
  background(175, 215, 230);
  
  colorMode(RGB, 255,255,255,1);
  
  fill(255,255,0.1);
  square(100,70,50, 50, 50, 50, 50); 
  triangle(115, 130, 125, 120, 135, 130);
  noFill();
  curve(100, 56, 125, 130, 73, 161, 15, 65);
  
  fill(255,0,0,0.5)
  square(210,110,50,50, 50, 50, 50);
  triangle(225, 165, 235, 160, 245, 165);
  noFill();
  curve(200, 56, 235, 165, 180, 201, 105, 165);
  
  fill(0,0,255,0.5);
  square(320,70,50,50, 50, 50, 50 );
  triangle(345, 121, 337, 130, 350, 130);
  noFill();
  curve(250, 56, 345, 130, 270, 190, 5, 105);
  
  fill(0,255,0,0.5)
  square(300,210,50, 50, 50, 50, 50);
  triangle(315, 270, 325, 260, 335, 270);
  noFill();
  curve(345, 56, 325, 270, 250, 310, 105, 300);
 
  
  //used to make lines easier
  quad(0, 50, 500, 150, 500, 50, 0, 150);
  quad(0, 70, 500, 150, 500, 70, 0, 150);
  quad(0, 90, 500, 100, 500, 70, 0, 130);
  
  
  
  
}
