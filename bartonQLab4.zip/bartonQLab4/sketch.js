  let squarex=25;
  let squarey=25;
  let gap=25;


  function setup() {
  createCanvas(500, 500);
}

function draw() {
  background(100);
  

  
  fill(squarex,squarey, squarex+squarey/2)
  square(squarex, squarey, 25)
  
if(keyIsPressed===true){
  if (key === 'w') {
    squarey -= 1;
  } else if (key === 's') {
    squarey += 1;
  }else if (key === 'd') {
    squarex += 1;
  }else if (key === 'a') {
    squarex += -1;
  }
}
  if (squarey>525){
    squarey=-25;
  }
  if (squarex>525){
    squarex=-25;
  }
  if (squarey<-25){
    squarey=500;
  } 
  if (squarex<-25){
    squarex=500;
  } 
   
 if (mouseIsPressed===true){
   squarex=pmouseX-25/2;
   squarey=pmouseY-25/2;
 }
  
  strokeWeight(3);
  
  for (let x=gap; x <500; x+=gap){
    for (let y=gap; y<500; y+=gap)
  
  point (x,y);
  
  }
  
  
  frameRate(200);
  
  
  
  
  
  
}